# KiyaaPayy WebView APK wrapper

Project Android native kecil yang membuka website KiyaaPayy Online dalam tampilan aplikasi (tanpa address bar browser).

## PENTING: pasang URL server dulu
File `app/build.gradle.kts`, cari:
`https://GANTI-DENGAN-URL-RENDER.onrender.com`

Ganti dengan URL Render KiyaaPayy Online yang sudah benar, misalnya `https://nama-service.onrender.com`.
Tanpa URL server yang sudah live, APK hanya akan menampilkan halaman gagal dimuat.

## Build APK dari GitHub (HP Android saja)
1. Upload **isi folder project ini** ke repository GitHub baru/kosong, bukan ZIP-nya saja.
2. Pastikan folder tersembunyi `.github/workflows/build-apk.yml` ikut ter-upload.
3. Buka tab Actions → workflow `Build KiyaaPayy APK` → `Run workflow` (atau tunggu build otomatis).
4. Jika hijau, buka run tersebut → Artifacts → `KiyaaPayy-APK` untuk mengunduh APK debug.
5. Ekstrak artifact ZIP dari GitHub, lalu install APK di Android.

## Fitur wrapper
- Tampilan full-screen WebView tanpa address bar.
- JavaScript dan penyimpanan web diaktifkan.
- Media playback diizinkan tanpa gesture tambahan.
- Tombol Back mengikuti navigasi halaman.

## Batasan
Ini adalah pembungkus Android untuk website, bukan mesin musik offline/native. Backend Python harus sudah online dan dapat diakses melalui HTTPS. Kualitas pemutaran background/notifikasi bergantung pada implementasi website dan Android WebView. Belum ada APK biner yang dibangun atau diuji dalam paket ini.

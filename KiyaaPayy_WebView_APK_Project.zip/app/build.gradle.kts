plugins {
    id("com.android.application")
}

android {
    namespace = "com.kiyaapay.web"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kiyaapay.web"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Ganti URL ini setelah KiyaaPayy Online berhasil di-deploy.
        buildConfigField("String", "WEB_APP_URL", "\"https://GANTI-DENGAN-URL-RENDER.onrender.com\"")
    }

    buildFeatures { buildConfig = true }
}
